package com.example.my_firstapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
